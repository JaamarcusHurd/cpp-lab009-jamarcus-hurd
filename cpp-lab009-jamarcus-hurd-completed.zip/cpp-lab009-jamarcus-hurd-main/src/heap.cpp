#include "project/heap.h"

#include <algorithm>
#include <stdexcept>

MaxHeap::MaxHeap() = default;

MaxHeap::MaxHeap(const std::vector<int>& values) { buildHeap(values); }

bool MaxHeap::empty() const noexcept { return data_.empty(); }
std::size_t MaxHeap::size() const noexcept { return data_.size(); }

int MaxHeap::top() const {
    if (empty()) throw std::logic_error("Heap is empty");
    return data_.front();
}

bool MaxHeap::contains(int value) const {
    return std::find(data_.begin(), data_.end(), value) != data_.end();
}

void MaxHeap::push(int value) {
    data_.push_back(value);
    heapifyUp(data_.size() - 1);
}

int MaxHeap::pop() {
    if (empty()) throw std::logic_error("Heap is empty");
    const int maximum = data_.front();
    if (data_.size() == 1) {
        data_.pop_back();
        return maximum;
    }
    data_.front() = data_.back();
    data_.pop_back();
    heapifyDown(0);
    return maximum;
}

void MaxHeap::buildHeap(const std::vector<int>& values) {
    data_ = values;
    // Bottom-up heap construction: leaves already satisfy the heap property.
    for (std::size_t i = data_.size() / 2; i > 0; --i) {
        heapifyDown(i - 1);
    }
}

std::vector<int> MaxHeap::heapSort() {
    // Sort a copy so the priority queue remains available to the caller.
    MaxHeap copy(*this);
    std::vector<int> result(copy.size());
    for (std::size_t i = result.size(); i > 0; --i) {
        result[i - 1] = copy.pop();
    }
    return result;
}

std::vector<int> MaxHeap::toVector() const { return data_; }

std::size_t MaxHeap::parentIndex(std::size_t index) {
    return index == 0 ? 0 : (index - 1) / 2;
}
std::size_t MaxHeap::leftChildIndex(std::size_t index) { return 2 * index + 1; }
std::size_t MaxHeap::rightChildIndex(std::size_t index) { return 2 * index + 2; }

void MaxHeap::heapifyUp(std::size_t index) {
    // Restore the invariant by moving a new value toward the root.
    while (index > 0) {
        const std::size_t parent = parentIndex(index);
        if (data_[parent] >= data_[index]) break;
        swap(data_[parent], data_[index]);
        index = parent;
    }
}

void MaxHeap::heapifyDown(std::size_t index) {
    // Restore the invariant by swapping with the larger existing child.
    const std::size_t n = data_.size();
    while (index < n) {
        std::size_t largest = index;
        // Avoid computing child indices unless index has children.
        if (index >= n / 2 && !(n % 2 && index == n / 2)) break;
        const std::size_t left = leftChildIndex(index);
        const std::size_t right = rightChildIndex(index);
        if (left < n && data_[left] > data_[largest]) largest = left;
        if (right < n && data_[right] > data_[largest]) largest = right;
        if (largest == index) break;
        swap(data_[index], data_[largest]);
        index = largest;
    }
}

void MaxHeap::swap(int& a, int& b) { std::swap(a, b); }

bool MaxHeap::isValidHeap() const {
    for (std::size_t i = 1; i < data_.size(); ++i) {
        if (data_[parentIndex(i)] < data_[i]) return false;
    }
    return true;
}
