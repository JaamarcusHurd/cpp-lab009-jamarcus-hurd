# Lab 9 — Heap Data Structure and Algorithm Analysis

## Heap property and array representation

A **max-heap** is a complete binary tree in which every parent is greater than or equal to both children. Therefore the maximum is stored at index 0. A `std::vector<int>` stores the nodes in level order without explicit pointers. For a node at zero-based index `i`, its parent is `(i - 1) / 2` (when `i > 0`), its left child is `2 * i + 1`, and its right child is `2 * i + 2`. Child indices are only valid when they are smaller than the vector's size. Equal values are allowed.

## How the operations work

- **push:** Append the value, then `heapifyUp` by swapping with its parent while the child is larger.
- **top:** Return the root without changing the heap; throw `std::logic_error` when empty.
- **pop:** Save the root, move the final element to the root, remove the final element, then `heapifyDown` by swapping with the larger child until the heap property is restored. An empty heap throws `std::logic_error`.
- **buildHeap:** Copy the input vector and call `heapifyDown` on each internal node in reverse order. This is faster than inserting every item separately.
- **heapSort:** Extract maxima from a copy of the heap and place them into the result from right to left, producing ascending order without changing the original heap.
- **contains:** Scan the vector; heap ordering does not support BST-style branching for arbitrary membership checks.

## Time and space complexity

| Operation | Time | Additional space |
| --- | --- | --- |
| `top`, `empty`, `size` | O(1) | O(1) |
| `push` | O(log n) worst case, O(1) best case | O(1) auxiliary, excluding vector growth |
| `pop` | O(log n) worst case, O(1) best case | O(1) |
| `contains` | O(n) worst case | O(1) |
| `buildHeap` | O(n) | O(n) to copy the input |
| `heapSort` | O(n log n) | O(n) for a heap copy and output |
| `heapifyUp`, `heapifyDown` | O(log n) worst case | O(1) |

A complete binary tree has height O(log n), limiting the number of swaps in insertion and removal. Bottom-up construction is O(n), not O(n log n), because most nodes are close to the leaves and require very little downward movement. The vector uses O(n) storage overall and automatically manages its allocated memory. A `push` can occasionally trigger vector reallocation, taking O(n) for that individual call; appending is O(1) amortized, and heap maintenance costs O(log n).

## Comparisons and appropriate uses

A **sorted vector** provides O(1) maximum lookup but O(n) insertion due to shifting elements; removing its last maximum is O(1). A **balanced BST** supports O(log n) insertion, search, and removal and additionally supports ordered iteration, while an ordinary unbalanced BST may degrade to O(n). A **heap** provides O(1) maximum lookup and O(log n) insertion/removal, but arbitrary searching takes O(n) and its underlying array is not fully sorted. A heap is therefore especially useful for priority queues, task schedulers, and repeatedly selecting the highest-priority item. Heap sort offers O(n log n) worst-case sorting; this implementation uses O(n) extra memory to preserve the original heap, unlike an in-place array heap sort.
